**click.html** is a test to make sure the resolution-rescaling code works
without throwing off click projection.

**lod.html** is the Level-of-Detail example showing how meshes can be made to
switch detail levels depending on distance from the camera.

**three.min.js** is the Three.js library.