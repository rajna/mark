**city.html** contains the main cityscape example used throughout the chapter
in its completed form.

**globe.html** contains the code used to generate the earth rendering that is
used to illustrate image mapping. It uses the *land_ocean_ice_cloud_2048.jpg*
file.

**shadowCamera.html** contains the code used to generate the rendering of the
DirectionLight shadow camera frustum.

**text.html** was used to generate image 8509_02_13.png of 3D text.

**three.min.js** is the Three.js library.
