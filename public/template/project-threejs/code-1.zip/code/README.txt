**8539_01_01.html** contains the "Hello, world"-style example that the first
chapter walks through. It can be executed by opening it in a browser.

**8539_01_02.html** generates the visualization of orthographic versus
perspective projection.  It can be executed by opening it in a browser.

**three.min.js** is the Three.js library that this book is about. It is
included here for convenience so that the rest of the code can be executed
without internet access to load the library from a CDN.
